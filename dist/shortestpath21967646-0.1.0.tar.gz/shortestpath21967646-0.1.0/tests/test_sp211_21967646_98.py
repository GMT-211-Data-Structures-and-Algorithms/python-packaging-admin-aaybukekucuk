from sp211_21967646_98.sp211_21967646_98 import dijkstra

def test_dijkstra_simple():
    graph = {
        'A': [('B', 1), ('C', 4)],
        'B': [('C', 2), ('D', 5)],
        'C': [('D', 1)],
        'D': []
    }

    result = dijkstra(graph, 'A')
    assert result['D'] == 4
    assert result['C'] == 3
    assert result['B'] == 1
    assert result['A'] == 0